/*  insert comments here */
#include "C4Board.h"   // class definition for C4Board used below
#include "C4Col.h"
#include <iostream>

using namespace std;

int main() {
	//creating an instance of the class C4Board
	C4Board game;
	//Calling the play function to start the game
	game.play();

	return 0;
}
